# triage-bundle

NovoSGA v2.0 triage module.
