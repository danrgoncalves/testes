# monitor-bundle
NovoSGA v2.0 monitor module.
