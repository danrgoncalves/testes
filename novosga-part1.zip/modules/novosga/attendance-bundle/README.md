# attendance-bundle
NovoSGA v2.0 attendance module.
