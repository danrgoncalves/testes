# settings-bundle
NovoSGA v2.0 settings module.
